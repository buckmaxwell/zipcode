import os
print os.path.dirname(os.path.abspath(__file__)
db_filename = 'zipcodes.db'
os.path.join(directory, db_filename)

